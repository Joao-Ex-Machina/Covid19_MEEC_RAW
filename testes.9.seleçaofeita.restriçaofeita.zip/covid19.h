/*-----------------------------------------------------------------------------------------------------+
| covid19.h              |Headers, structs and other definitions module for covid19_main.c             |
|                        |                                                                             |
|                        |                                                                             |
+------------------------------------------------------------------------------------------------------+
| Authors: Joao Barreiros C. Rodrigues (Joao-Ex-Machina) n�99968, Henrique "Delfas" Delfino            |
| Date: 09 May 2021                                                                                    |
+-----------------------------------------------------------------------------------------------------*/
#ifndef COVID19_H_INCLUDED
#define COVID19_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


typedef struct country_list{
char country[30];
char country_code[4];
char continent[15];
long population;
struct week_list *week_pointer;
struct country_list *next;
}country_list;

typedef struct week_list{
long death_Weekly_count, death_cumulative_count, infected_Weekly_count, infected_cumulative_count, year, week;
double death_rate_14_day, infected_rate_14_day;
char indicator[30];
struct week_list *next;

}week_list;
country_list* readfile(char* _filename, country_list* header);
void dataselection(country_list *heade);
//void restricting(country_list *heade);


#endif
