/*-----------------------------------------------------------------------------------------------------+
| covid19_main.c         |Main module for The Programming Curricular Unit final Project- "Covid19"     |
|                        |Directives can be found here:                                                |
|                        |                                                                             |
+------------------------------------------------------------------------------------------------------+
| Authors: Joao Barreiros C. Rodrigues (Joao-Ex-Machina) n�99968, Henrique "Delfas" Delfino            |
| Date: 09 May 2021                                                                                    |
+-----------------------------------------------------------------------------------------------------*/
#include "covid19.h"

int main(){
 country_list *header, *aux;
 week_list *auxweek;
 header = (country_list *)malloc(1*(sizeof(country_list)));
    header->next = NULL;

header = readfile("covid19_w_t01.txt", &header);
aux = header;
dataselection(aux);
//----------------------JOAO LE O COMENTARIO EM BAIXO--------------------------------------------------------------------\\
//n�o tenhas um ataque cardiaco quando vires isto, isto vai sair daqui, � s� enquanto n�o temos as flags
    char string[40] = {'\0'};
    country_list  *aux2 = NULL;
    week_list *auxweek2 = NULL;
    aux2 = header;
    printf("printa ai as cenas das restri��es meu brou\n");
    gets(string);
    gets(string);
    printf("%s", string);

restricting(aux, string);








}
