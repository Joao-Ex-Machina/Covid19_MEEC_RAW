/*-----------------------------------------------------------------------------------------------------+
| covid19_read_module.c  |Read module for covid19_main.c                                               |
|                        |                                                                             |
|                        |                                                                             |
+------------------------------------------------------------------------------------------------------+
| Authors: Joao Barreiros C. Rodrigues (Joao-Ex-Machina) n�99968, Henrique "Delfas" Delfino            |
| Date: 09 May 2021                                                                                    |
+-----------------------------------------------------------------------------------------------------*/
#include "covid19.h"

/*Function Name:
  Input:
  Output:
  Date Created: 13 May 2021
  Last Revised: 15 May 2021
  Definition:
*/
void printlist (country_list *head, week_list *auxweek, int indicator[15]){
country_list *temporary = head;
week_list *temporary2 = auxweek;
printf(" %s %s %s %ld %s %ld %ld %ld %lf %ld\n", temporary->country, temporary->country_code, temporary->continent, temporary->population,indicator, temporary2->Weekly_count, temporary2->year, temporary2->week, temporary2->rate_14_day, temporary2->cumulative_count);
}

/*Function Name:
  Input:
  Output:
  Date Created: 13 May 2021
  Last Revised: 15 May 2021
  Definition:
*/
void free_list(country_list *listhead)
{
    country_list *auxfree;
    auxfree = listhead;
    while ( listhead != NULL)
    {
        auxfree = listhead;
        listhead = listhead->week_pointer;
        free(auxfree->next);
        free(auxfree);
    }
}


/*Function Name:
  Input:
  Output:
  Date Created: 13 May 2021
  Last Revised: 15 May 2021
  Definition:
*/
country_list *create_new_country(char name[120], char country_code[4], char continent[25],long population){
    country_list *new_country = (country_list*)malloc(sizeof(country_list));
    strcpy(new_country->country, name);
    strcpy(new_country->country_code, country_code);
    strcpy(new_country->continent, continent);
    new_country->population = population;
    new_country->next = NULL;
    new_country->week_pointer = NULL;

    return new_country;

}
/*Function Name:
  Input:
  Output:
  Date Created: 13 May 2021
  Last Revised: 15 May 2021
  Definition:
*/
week_list *create_new_week(char indicator[15], long weekly_count,int year,int week,float rate_14_day,long cumulative_count){
    week_list *new_week = (week_list*)malloc(sizeof(week_list));

            new_week->Weekly_count = weekly_count;
            new_week->year = year;
            new_week->week = week;
            new_week->rate_14_day = rate_14_day;
            new_week->cumulative_count = cumulative_count;
            new_week->next = NULL;
            strcpy(new_week->indicator,indicator);

        return new_week;
}

/*Function Name:
  Input:
  Output:
  Date Created: 13 May 2021
  Last Revised: 15 May 2021
  Definition:
*/
char** readfile(char* _filename){
   FILE *fp = fopen(_filename,"r");
    char string[500] = {'\0'};
    char name[30] = {'\0'};
    char country_code[4] = {'\0'};
    char continent[15] = {'\0'};
    char chosen_continent[15] = {'\0'};
    long population = 0, weekly_count = 0, cumulative_count = 0, year = 0, week = 0;
    double rate_14_day;
    country_list *header = NULL, *aux = NULL, *aux2 = NULL;
    week_list *auxweek = NULL;
    char indicator[15];
   fgets(string,400,fp);
   scanf("%s", &chosen_continent); //rudimentar continent reader restriction
    while (strcmp(continent,chosen_continent) != 0 && fgets(string,400,fp) != 0){
    name[500] = "";
    country_code[4] = "";
    continent[15] = "";
    indicator[15] = "";
    rate_14_day = 0;
    population = 0, weekly_count = 0, cumulative_count = 0, year = 0, week = 0;
    sscanf(string, "%[a-zA-Z ],%[a-zA-Z ],%[a-zA-Z ],%ld,%[a-zA-Z ],%ld,%ld-%ld,%lf,%ld", name, country_code, continent, &population, indicator, &weekly_count, &year, &week, &rate_14_day, &cumulative_count);



    if (strcmp(chosen_continent,"all") == 0){
        break;
    }
    }
    header = create_new_country(name, country_code, continent, population);
    header->week_pointer = create_new_week(indicator, weekly_count, year, week, rate_14_day,cumulative_count );
    auxweek = header->week_pointer;
    printlist(header, auxweek, indicator);
    aux = header;


   while (fgets(string,400,fp)!=0)
   {
    name[500] = "";
    country_code[4] = "";
    continent[15] = "";
    indicator[15] = "";
    rate_14_day = 0;
    population = 0, weekly_count = 0, cumulative_count = 0, year = 0, week = 0;
    sscanf(string, "%[a-zA-Z ],%[a-zA-Z ],%[a-zA-Z ],%d,%[a-zA-Z ],%d,%d-%d,%lf,%d ", name,country_code,continent, &population, indicator, &weekly_count, &year, &week, &rate_14_day,&cumulative_count );
    if (strcmp(continent,chosen_continent) == 0 || strcmp(chosen_continent,"all") == 0){
            if (strcmp(aux->country,name) == 0){
                auxweek->next = create_new_week(indicator, weekly_count, year, week, rate_14_day,cumulative_count );
                auxweek = auxweek->next;
            }else{
            aux->next = create_new_country(name, country_code, continent, population);
            aux = aux->next;
            auxweek->next = create_new_week(indicator, weekly_count, year, week, rate_14_day,cumulative_count );
            auxweek = auxweek->next;
            }
    printlist(aux, auxweek, indicator);
   }
   }
free_list(header);
}
