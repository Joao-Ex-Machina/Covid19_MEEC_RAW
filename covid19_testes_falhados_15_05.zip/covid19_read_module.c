/*-----------------------------------------------------------------------------------------------------+
| covid19_read_module.c  |Read module for covid19_main.c                                               |
|                        |                                                                             |
|                        |                                                                             |
+------------------------------------------------------------------------------------------------------+
| Authors: Joao Barreiros C. Rodrigues (Joao-Ex-Machina) n�99968, Henrique "Delfas" Delfino            |
| Date: 09 May 2021                                                                                    |
+-----------------------------------------------------------------------------------------------------*/
#include "covid19.h"
//created 13/05
void printlist (country_list *head, week_list *auxweek, int indicator[15]){
country_list *temporary = head;
week_list *temporary2 = auxweek;
if (strcmp(indicator,"cases")){
printf(" %s %s %s %d %s %d %d %d %f %d\n", temporary->name, temporary->acronymn, temporary->continent, temporary->population,indicator, temporary2->InfectedWeekly, temporary2->year, temporary2->week, temporary2->InfectedRatio, temporary2->InfectedTotal);
}else if (strcmp(indicator,"deaths")){
printf(" %s %s %s %d %s %d %d %d %f %d\n", temporary->name, temporary->acronymn, temporary->continent, temporary->population,indicator, temporary2->DeathWeekly, temporary2->year, temporary2->week, temporary2->DeathRatio, temporary2-> DeathTotal);

}
}

//created 13/05
country_list *create_new_country(char name[120], char acronymn[4], char continent[25],int population){
    country_list *new_country = (country_list*)malloc(sizeof(country_list));
    strcpy(new_country->name, name);
    strcpy(new_country->acronymn, acronymn);
    strcpy(new_country->continent, continent);
    new_country->population = population;
    new_country->next = NULL;
    new_country->week_pointer = NULL;

    return new_country;

}
//function to create a struct with the information for the respective week
week_list *create_new_week(int indicator[15], int weekly_count,int year,int week,float rate_14_day,int cumulative_count){
    week_list *new_week = (week_list*)malloc(sizeof(week_list));
    if (strcmp(indicator,"cases") == 0)
        {
            new_week->InfectedWeekly = weekly_count;
            new_week->year = year;
            new_week->week = week;
            new_week->InfectedRatio = rate_14_day;
            new_week->InfectedTotal = cumulative_count;
            new_week->next = NULL;
        }else if (strcmp(indicator,"deaths"))
            {
                new_week->DeathWeekly = weekly_count;
                new_week->year = year;
                new_week->week = week;
                new_week->InfectedRatio =  rate_14_day;
                new_week->InfectedTotal =  cumulative_count;
                new_week->next = NULL;
            }
        return new_week;
}

char** readfile(char* _filename){
   FILE *fp = fopen(_filename,"r");
    char string[500] = {'\0'};
    char name[500] = {'\0'};
    char acronymn[500] = {'\0'};
    char continent[500] = {'\0'};
    char chosen_continent[500] = {'\0'};
    int population = 0, weekly_count = 0, cumulative_count = 0, year = 0, week = 0;
    float rate_14_day;
    country_list *header = NULL, *aux = NULL, *aux2 = NULL;
    week_list *auxweek = NULL;
    char indicator[15];
   fgets(string,400,fp);
   scanf("%s", &chosen_continent);
    while (strcmp(continent,chosen_continent) != 0){
    fgets(string,400,fp);
    sscanf(string, "%[a-zA-Z ],%[a-zA-Z ],%[a-zA-Z ],%d,%[a-zA-Z ],%d,%d-%d,%f,%d ", name,acronymn,continent, &population, indicator, &weekly_count, &year, &week, &rate_14_day, &cumulative_count );
    printf("%s %s %s %d %s %d %d %d %f %d\n", name, acronymn,continent, population, indicator, weekly_count, year, week, rate_14_day, cumulative_count);
    if (strcmp(chosen_continent,"all") == 0){
        break;
    }
    }
    header = create_new_country(name, acronymn, continent, population);
    header->week_pointer = create_new_week(indicator, weekly_count, year, week, rate_14_day,cumulative_count );
    auxweek = header->week_pointer;
    printlist(header, auxweek, indicator);
    aux = header;


   while (fgets(string,400,fp)!=0)
   {
    sscanf(string, "%[a-zA-Z ],%[a-zA-Z ],%[a-zA-Z ],%d,%[a-zA-Z ],%d,%d-%d,%f,%d ", name,acronymn,continent, &population, indicator, &weekly_count, &year, &week, &rate_14_day,&cumulative_count );
    if (strcmp(continent,chosen_continent) == 0 || strcmp(chosen_continent,"all") == 0){
            if (strcmp(aux->name,name) == 0){
                auxweek->next = create_new_week(indicator, weekly_count, year, week, rate_14_day,cumulative_count );
                auxweek = auxweek->next;
            }else{
            aux->next = create_new_country(name, acronymn, continent, population);
            aux = aux->next;
            auxweek->next = create_new_week(indicator, weekly_count, year, week, rate_14_day,cumulative_count );
            auxweek = auxweek->next;
            }
    printlist(header, auxweek, indicator);
   }
   }

}

